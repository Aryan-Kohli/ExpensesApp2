import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const Transactions = () => {
  return (
    <View style={styles.transactions}>
      <View style={styles.transactionsChild} />
      <View style={[styles.transactionsItem, styles.rectangleViewPosition]} />
      <Text style={styles.eventName}>Event Name</Text>
      <Image
        style={styles.transactionsInner}
        contentFit="cover"
        source={require("../assets/arrow-22.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.transactionsChildLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-13.png")}
      />
      <Image
        style={[styles.transactionsChild1, styles.transactionsChildLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-33.png")}
      />
      <Image
        style={[styles.transactionsChild2, styles.transactionsChildLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-34.png")}
      />
      <Text style={[styles.aayush, styles.textTypo]}>{`Aayush `}</Text>
      <Text style={[styles.yashika, styles.textTypo]}>Yashika</Text>
      <Text style={[styles.aryan, styles.textTypo]}>Aryan</Text>
      <View style={[styles.rectangleView, styles.rectangleViewPosition]} />
      <Text style={[styles.payer, styles.descPosition]}>Payer</Text>
      <Text style={[styles.desc, styles.descTypo]}>DESC</Text>
      <Text style={[styles.amount, styles.textTypo]}>Amount</Text>
      <Text style={[styles.beakfast, styles.descTypo]}>Beakfast</Text>
      <Text style={[styles.lunch, styles.lunchTypo]}>Lunch</Text>
      <Text style={[styles.dinner, styles.text2Typo]}>Dinner</Text>
      <Text style={[styles.text, styles.textTypo]}>300/-</Text>
      <Text style={[styles.text1, styles.lunchTypo]}>500/-</Text>
      <Text style={[styles.text2, styles.text2Typo]}>450/-</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleViewPosition: {
    left: 19,
    position: "absolute",
  },
  transactionsChildLayout: {
    width: 336,
    borderRadius: Border.br_11xl,
    left: 12,
    position: "absolute",
  },
  textTypo: {
    color: Color.colorWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    position: "absolute",
  },
  descPosition: {
    top: 132,
    fontStyle: "italic",
  },
  descTypo: {
    left: 29,
    color: Color.colorWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    position: "absolute",
  },
  lunchTypo: {
    top: 363,
    color: Color.colorWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    position: "absolute",
  },
  text2Typo: {
    top: 492,
    color: Color.colorWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    position: "absolute",
  },
  transactionsChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.colorLightblue,
    width: 360,
    position: "absolute",
    height: 800,
  },
  transactionsItem: {
    top: 25,
    borderRadius: Border.br_21xl,
    backgroundColor: Color.colorSalmon,
    width: 85,
    height: 64,
  },
  eventName: {
    top: 33,
    left: 113,
    fontSize: FontSize.size_17xl,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "left",
    fontStyle: "italic",
    position: "absolute",
  },
  transactionsInner: {
    top: 55,
    width: 45,
    height: 2,
    left: 36,
    position: "absolute",
  },
  rectangleIcon: {
    top: 186,
    height: 114,
  },
  transactionsChild1: {
    top: 322,
    height: 115,
  },
  transactionsChild2: {
    top: 459,
    height: 120,
  },
  aayush: {
    top: 357,
    left: 140,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
  },
  yashika: {
    top: 490,
    left: 140,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
  },
  aryan: {
    left: 144,
    top: 229,
  },
  rectangleView: {
    top: 107,
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorSteelblue_100,
    width: 329,
    height: 70,
  },
  payer: {
    color: Color.colorWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    position: "absolute",
    left: 140,
  },
  desc: {
    top: 132,
    fontStyle: "italic",
  },
  amount: {
    top: 128,
    left: 239,
    fontStyle: "italic",
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_5xl,
  },
  beakfast: {
    top: 229,
  },
  lunch: {
    left: 36,
  },
  dinner: {
    left: 42,
  },
  text: {
    left: 251,
    top: 229,
  },
  text1: {
    left: 259,
  },
  text2: {
    left: 254,
  },
  transactions: {
    backgroundColor: "#d0efff",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default Transactions;
