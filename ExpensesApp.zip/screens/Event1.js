import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Event1 = () => {
  return (
    <View style={[styles.event, styles.eventLayout1]}>
      <View style={[styles.eventChild, styles.eventLayout1]} />
      <View style={[styles.eventItem, styles.eventLayout]} />
      <View style={[styles.eventInner, styles.eventLayout]} />
      <View style={[styles.rectangleView, styles.eventLayout]} />
      <View style={styles.frameView}>
        <View style={[styles.frameChild, styles.eventLayout]} />
      </View>
      <Text style={styles.eventName}>Event Name</Text>
      <View style={[styles.eventChild1, styles.eventPosition]} />
      <Image
        style={styles.arrowIcon}
        contentFit="cover"
        source={require("../assets/arrow-2.png")}
      />
      <Text style={[styles.addNewMember, styles.addTypo]}>
        + Add new member
      </Text>
      <Text style={[styles.seeAllMembers, styles.addTypo]}>
        See all members
      </Text>
      <Text style={[styles.addTansaction, styles.addTypo]}>Add Tansaction</Text>
      <Text style={[styles.seeAllTransaction, styles.addTypo]}>
        See all transaction
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  eventLayout1: {
    height: 800,
    backgroundColor: Color.colorLightblue,
  },
  eventLayout: {
    height: 71,
    width: 321,
    borderRadius: Border.br_6xl,
  },
  eventPosition: {
    left: 14,
    position: "absolute",
  },
  addTypo: {
    color: Color.colorWhite,
    fontSize: FontSize.size_13xl,
    textAlign: "left",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontStyle: "italic",
    position: "absolute",
  },
  eventChild: {
    top: 0,
    left: 0,
    width: 360,
    position: "absolute",
  },
  eventItem: {
    top: 158,
    backgroundColor: Color.colorDarkslategray_100,
    width: 321,
    borderRadius: Border.br_6xl,
    left: 14,
    position: "absolute",
  },
  eventInner: {
    top: 264,
    backgroundColor: "#3a96c8",
    width: 321,
    borderRadius: Border.br_6xl,
    left: 14,
    position: "absolute",
  },
  rectangleView: {
    top: 370,
    backgroundColor: Color.colorDarkslategray_100,
    width: 321,
    borderRadius: Border.br_6xl,
    left: 14,
    position: "absolute",
  },
  frameChild: {
    backgroundColor: "#40a5dc",
    width: 321,
    borderRadius: Border.br_6xl,
  },
  frameView: {
    top: 466,
    left: 4,
    padding: 10,
    position: "absolute",
  },
  eventName: {
    top: 40,
    left: 114,
    fontSize: FontSize.size_17xl,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    fontStyle: "italic",
    position: "absolute",
  },
  eventChild1: {
    top: 31,
    borderRadius: Border.br_21xl,
    backgroundColor: Color.colorSalmon,
    width: 85,
    height: 64,
  },
  arrowIcon: {
    top: 62,
    left: 34,
    width: 45,
    height: 1,
    position: "absolute",
  },
  addNewMember: {
    top: 174,
    left: 24,
  },
  seeAllMembers: {
    top: 277,
    left: 45,
  },
  addTansaction: {
    top: 386,
    left: 56,
  },
  seeAllTransaction: {
    top: 492,
    left: 29,
  },
  event: {
    flex: 1,
    width: "100%",
    overflow: "hidden",
  },
});

export default Event1;
