import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Modal1 = () => {
  return (
    <View style={styles.modal}>
      <View style={[styles.modalChild, styles.childPosition]} />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={styles.enterName}>Enter Name</Text>
        <Text style={[styles.save, styles.saveTypo]}>Save</Text>
        <View style={[styles.groupInner, styles.groupLayout]} />
        <View style={styles.rectangleView} />
      </View>
      <Text style={[styles.cancel, styles.saveTypo]}>Cancel</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  childPosition: {
    left: 0,
    top: 0,
  },
  groupChildLayout: {
    height: 353,
    width: 336,
    position: "absolute",
  },
  groupLayout: {
    height: 88,
    width: 128,
    backgroundColor: Color.colorSalmon,
    borderRadius: Border.br_21xl,
    top: 248,
    position: "absolute",
  },
  saveTypo: {
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  modalChild: {
    backgroundColor: Color.colorLightblue,
    width: 360,
    position: "absolute",
    height: 800,
  },
  groupChild: {
    borderRadius: Border.br_11xl,
    backgroundColor: Color.colorDarkslategray_100,
    left: 0,
    top: 0,
  },
  groupItem: {
    left: 18,
  },
  enterName: {
    top: 73,
    left: 24,
    fontStyle: "italic",
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    width: 216,
    height: 64,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_17xl,
    position: "absolute",
  },
  save: {
    top: 269,
    left: 32,
    fontSize: 38,
    width: 100,
    height: 36,
  },
  groupInner: {
    left: 184,
  },
  rectangleView: {
    top: 126,
    left: 8,
    borderRadius: Border.br_31xl,
    backgroundColor: Color.colorWhite,
    width: 316,
    height: 78,
    position: "absolute",
  },
  rectangleParent: {
    top: 214,
    left: 12,
  },
  cancel: {
    top: 483,
    left: 198,
    fontSize: FontSize.size_17xl,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  modal: {
    backgroundColor: "#f4fbff",
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default Modal1;
