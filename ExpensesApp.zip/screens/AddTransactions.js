import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const AddTransactions = () => {
  return (
    <View style={styles.addTransactions}>
      <View style={styles.addTransactionsChild} />
      <View style={styles.addTransactionsItem} />
      <Text style={styles.eventName}>Event Name</Text>
      <Image
        style={styles.addTransactionsInner}
        contentFit="cover"
        source={require("../assets/arrow-22.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.addChildLayout1]}
        contentFit="cover"
        source={require("../assets/rectangle-14.png")}
      />
      <Image
        style={[styles.addTransactionsChild1, styles.addChildLayout1]}
        contentFit="cover"
        source={require("../assets/rectangle-331.png")}
      />
      <Image
        style={[styles.addTransactionsChild2, styles.addChildLayout1]}
        contentFit="cover"
        source={require("../assets/rectangle-341.png")}
      />
      <View style={styles.rectangleView} />
      <Image
        style={[styles.addTransactionsChild3, styles.addChildLayout1]}
        contentFit="cover"
        source={require("../assets/rectangle-39.png")}
      />
      <Text style={[styles.enterPayersName, styles.enterTypo1]}>
        Enter Payer’s Name:
      </Text>
      <Text style={[styles.enterAmount, styles.enterTypo1]}>Enter Amount:</Text>
      <Text
        style={[styles.enterPersonsName, styles.enterTypo1]}
      >{`Enter Person’s Name
 to spilt:`}</Text>
      <Text style={[styles.enterAmount1, styles.enterTypo]}>Enter Amount:</Text>
      <Text style={[styles.enterNameHere, styles.enterTypo]}>
        Enter Name here:
      </Text>
      <Text style={[styles.enterName, styles.enterTypo]}>{`Enter Name `}</Text>
      <Text style={[styles.savePerson, styles.enterTypo]}>{`  Save
Person`}</Text>
      <Text style={[styles.saveTransactions, styles.enterTypo]}>{`       Save
Transactions`}</Text>
      <View style={[styles.addTransactionsChild4, styles.addChildLayout]} />
      <View style={[styles.addTransactionsChild5, styles.addChildLayout]} />
    </View>
  );
};

const styles = StyleSheet.create({
  addChildLayout1: {
    borderRadius: Border.br_11xl,
    position: "absolute",
  },
  enterTypo1: {
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    color: Color.colorBlack,
    fontStyle: "italic",
    position: "absolute",
  },
  enterTypo: {
    color: Color.colorSilver,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    fontStyle: "italic",
    position: "absolute",
  },
  addChildLayout: {
    height: 47,
    width: 360,
    backgroundColor: Color.colorLightblue,
    left: 0,
    position: "absolute",
  },
  addTransactionsChild: {
    top: 0,
    width: 360,
    backgroundColor: Color.colorLightblue,
    left: 0,
    position: "absolute",
    height: 800,
  },
  addTransactionsItem: {
    top: 25,
    borderRadius: Border.br_21xl,
    backgroundColor: Color.colorSalmon,
    width: 85,
    height: 64,
    left: 19,
    position: "absolute",
  },
  eventName: {
    top: 33,
    left: 113,
    fontSize: FontSize.size_17xl,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    textAlign: "left",
    color: Color.colorBlack,
    fontStyle: "italic",
    position: "absolute",
  },
  addTransactionsInner: {
    top: 55,
    width: 45,
    height: 2,
    left: 36,
    position: "absolute",
  },
  rectangleIcon: {
    top: 253,
    width: 213,
    height: 114,
    left: 12,
  },
  addTransactionsChild1: {
    top: 425,
    width: 277,
    height: 98,
    left: 19,
  },
  addTransactionsChild2: {
    top: 559,
    width: 130,
    height: 120,
    left: 12,
  },
  rectangleView: {
    top: 136,
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorSteelblue_100,
    width: 284,
    height: 70,
    left: 12,
    position: "absolute",
  },
  addTransactionsChild3: {
    top: 564,
    left: 154,
    width: 204,
    height: 115,
  },
  enterPayersName: {
    top: 98,
    left: 28,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
  },
  enterAmount: {
    top: 221,
    left: 31,
  },
  enterPersonsName: {
    top: 367,
    left: 28,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
  },
  enterAmount1: {
    top: 297,
    left: 32,
  },
  enterNameHere: {
    top: 157,
    left: 41,
  },
  enterName: {
    top: 459,
    left: 36,
  },
  savePerson: {
    top: 590,
    left: 39,
  },
  saveTransactions: {
    top: 581,
    left: 178,
    width: 156,
  },
  addTransactionsChild4: {
    top: 753,
  },
  addTransactionsChild5: {
    top: 706,
  },
  addTransactions: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 800,
  },
});

export default AddTransactions;
