import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const EventPage = () => {
  return (
    <View style={styles.eventPage}>
      <View style={styles.eventPageChild} />
      <Image
        style={styles.eventPageItem}
        contentFit="cover"
        source={require("../assets/rectangle-2.png")}
      />
      <View style={styles.eventPageInner} />
      <View style={[styles.rectangleView, styles.ellipseIconLayout]} />
      <View style={styles.eventPageChild1} />
      <Text style={[styles.save, styles.saveTypo]}>Save</Text>
      <Text style={[styles.enterEventName, styles.infoTypo]}>
        Enter Event Name
      </Text>
      <Text style={[styles.createAnEvent, styles.eventPosition]}>
        Create an event
      </Text>
      <Text style={[styles.info, styles.infoTypo]}>INFO</Text>
      <View style={[styles.eventPageChild2, styles.eventPosition]} />
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-21.png")}
      />
      <View style={[styles.eventPageChild3, styles.eventChildLayout]} />
      <View style={[styles.eventPageChild4, styles.eventChildLayout]} />
      <Text style={[styles.delete, styles.saveTypo]}>Delete</Text>
      <Text style={[styles.open, styles.saveTypo]}>Open</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  ellipseIconLayout: {
    width: 77,
    position: "absolute",
  },
  saveTypo: {
    textAlign: "left",
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  infoTypo: {
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    position: "absolute",
  },
  eventPosition: {
    left: 13,
    position: "absolute",
  },
  eventChildLayout: {
    height: 35,
    width: 78,
    backgroundColor: Color.colorSalmon,
    position: "absolute",
  },
  eventPageChild: {
    top: -9,
    left: 0,
    borderBottomRightRadius: Border.br_11xl,
    borderBottomLeftRadius: Border.br_11xl,
    width: 360,
    height: 267,
    backgroundColor: Color.colorDarkslategray_100,
    position: "absolute",
  },
  eventPageItem: {
    top: 258,
    left: 2,
    width: 357,
    height: 542,
    position: "absolute",
  },
  eventPageInner: {
    marginLeft: -167,
    top: 129,
    left: "50%",
    borderRadius: Border.br_6xl,
    width: 260,
    height: 69,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  rectangleView: {
    top: 31,
    left: 271,
    backgroundColor: "#fea3a3",
    height: 46,
    borderRadius: Border.br_mini,
  },
  eventPageChild1: {
    top: 216,
    borderRadius: 10,
    width: 64,
    height: 34,
    backgroundColor: Color.colorSalmon,
    left: 261,
    position: "absolute",
  },
  save: {
    top: 219,
    left: 268,
    width: 82,
    height: 31,
    color: Color.colorBlack,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  enterEventName: {
    top: 144,
    fontFamily: FontFamily.interRegular,
    color: "#ada9a9",
    left: 26,
  },
  createAnEvent: {
    top: 71,
    fontSize: 40,
    color: Color.colorWhite,
    textAlign: "left",
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
  },
  info: {
    top: 41,
    left: 280,
    fontWeight: "800",
    fontFamily: FontFamily.interExtraBold,
    width: 68,
    height: 26,
    color: Color.colorBlack,
  },
  eventPageChild2: {
    top: 320,
    width: 332,
    height: 94,
    borderRadius: Border.br_mini,
    backgroundColor: Color.colorDarkslategray_100,
  },
  ellipseIcon: {
    top: 332,
    height: 68,
    left: 26,
  },
  eventPageChild3: {
    top: 361,
    left: 141,
    borderRadius: 4,
  },
  eventPageChild4: {
    top: 363,
    left: 254,
    borderRadius: 5,
  },
  delete: {
    top: 372,
    color: Color.colorBlack,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
    left: 261,
  },
  open: {
    top: 367,
    left: 152,
    color: Color.colorBlack,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  eventPage: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default EventPage;
